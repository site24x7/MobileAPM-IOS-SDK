//
//  ZALog.h
//  JAnalytics
//
//  Created by Giridhar on 18/04/16.
//  Copyright © 2016 zoho. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "ZAEnums.h"

/**
 *  Use these method in your own application to log, isntead of NSLog.
 *  This does the same thing as NSLog, but typically, we developers use NSLog during development.
 Don't use this macro for printing URLs with Authtoken, but use it efficiently to track your app's logs.
 So that, we can send these logs to you!
 *  @param msg NSLog message
 *  @param ... NSLog arguments
 *
 *  @return prints on the console.
 */

#define ZALogVerbose(args...) ZLogExtension(__FILE__,__LINE__,__func__,"verbose",args);

#define ZALogDebug(args...) ZLogExtension(__FILE__,__LINE__,__func__,"debug",args);

#define ZALogInfo(args...) ZLogExtension(__FILE__,__LINE__,__func__,"info",args);

#define ZALogWarn(args...) ZLogExtension(__FILE__,__LINE__,__func__,"warning",args);

#define ZALogError(args...) ZLogExtension(__FILE__,__LINE__,__func__,"error",args);

//For Framework use only
#define IVLog(args...) ZLogExtensionInternal(__FILE__,__LINE__,__func__,"verbose",args);

/**
 *  A Custome Logger for logging both JAnalytics data and your own app data.
 */
@interface ZALog : NSObject

/**
 *  Shows Janalytics logs, collected data, and other network calls when set as YES. Janalytics doesn't log in Release mode.
 */
@property BOOL shouldLog;

/**
 *  Shows detailed logs of janalytics
 */

@property BOOL shouldDetailLog;


@property (nonatomic, retain) NSDateFormatter *dateFormatter;

@property (nonatomic, retain) NSString *dirLogsPath;

@property (nonatomic) NSStringEncoding logEncoding;

/**
 *  Returns shared ZALog instance.
 */

@property (nonatomic) ZALogLevel defaultLogLevel;

@property (nonatomic, strong, readonly) dispatch_queue_t loggerQueue;

@property (nonatomic, retain) NSString *logsDirectory;

@property (readwrite, assign, nonatomic) NSUInteger maximumNumberOfLogFiles;

+ (ZALog *) getInstance;

- (void) ZLSExtension : (NSString*) file lineNumber : (int) linenumber functionName : (NSString*) functionname type : (NSString*) type format : (NSString*) format;

- (void) setLogLevel:(ZALogLevel) logLevel;

-(void) setMaximumFileSize : (unsigned long long) newMaximumFileSize;

-(void) setMaximumNumberOfLogFiles:(NSUInteger)maximumNumberOfLogFiles;

void ZLogExtension(const char *file, int lineNumber, const char *functionName,const char *type, NSString *format, ...);

void ZLogExtensionInternal(const char *file, int lineNumber, const char *functionName,const char *type, NSString *format, ...);

//- (NSString*) getLogs;

- (void) clearConsoleLogs;

@end
