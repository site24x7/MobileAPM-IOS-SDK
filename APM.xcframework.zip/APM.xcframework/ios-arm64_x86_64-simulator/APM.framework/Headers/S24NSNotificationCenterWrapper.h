//
//  S24NSNotificationCenterWrapper.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 21/02/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "S24Constants.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * A wrapper around NSNotificationCenter used to add or remove to the subscribers. Orelse, make sure properly subscribes to NSNotificationCenter.
 */

@interface S24NSNotificationCenterWrapper : NSObject

#if S24_CAN_USE_UIDEVICE

@property (nonatomic, readonly, copy, class) NSNotificationName didBecomeActiveNotificationName;
@property (nonatomic, readonly, copy, class) NSNotificationName willResignActiveNotificationName;
@property (nonatomic, readonly, copy, class) NSNotificationName willTerminateNotificationName;

#endif

- (void)addObserver:(id)observer selector:(SEL)aSelector name:(NSNotificationName)aName;

- (void)removeObserver:(id)observer name:(NSNotificationName)aName object:(id)anObject;

- (void)removeObserver:(id)observer name:(NSNotificationName)aName;

- (void)removeObserver:(id)observer;

- (void)postNotificationName:(NSNotificationName)aName object:(id)anObject;

@end

NS_ASSUME_NONNULL_END
