//
//  S24AppState.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 14/02/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface S24AppState : NSObject

- (instancetype)initWithReleaseName:(NSString *)releaseName
                    osVersion:(NSString *)osVersion
                     vendorId:(NSString *)vendorId
                  isDebugging:(BOOL)isDebugging
                systemBootTimestamp:(NSDate *)systemBootTimestamp;

- (instancetype)initWithJSONObject:(NSDictionary *)jsonObject;

- (NSDictionary<NSString *, id> *)getAsJSONDictionary;

+ (S24AppState *)applicationStateWithData:(NSData *)data;

@property (readonly, nonatomic, copy) NSString *releaseName;

@property (readonly, nonatomic, copy) NSString *osVersion;

@property (readonly, nonatomic, copy) NSString *vendorId;

@property (readonly, nonatomic, assign) BOOL isDebugging;
/**
 * The boot time of the system rounded down to seconds. As the precision of the serialization is
 * only milliseconds and a precision of seconds is enough we round down to seconds. With this we
 * avoid getting different dates before and after serialization.
 */
@property (readonly, nonatomic, copy) NSDate *systemBootTimestamp;

@property (nonatomic, assign) BOOL isActive;

@property (nonatomic, assign) BOOL wasTerminated;

@property (nonatomic, assign) BOOL isSDKRunning;

@end

NS_ASSUME_NONNULL_END
