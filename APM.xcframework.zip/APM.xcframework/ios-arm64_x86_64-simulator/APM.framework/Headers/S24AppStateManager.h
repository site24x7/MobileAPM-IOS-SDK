//
//  S24AppStateManager.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 10/02/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "S24AppState.h"
#import "S24Constants.h"
//#import "S24CrashWrapper.h"
#import "S24DispatchQueueWrapper.h"
#import "S24CurrentDateProvider.h"
#import "S24Sysctl.h"
#import "S24NSNotificationCenterWrapper.h"


NS_ASSUME_NONNULL_BEGIN

@interface S24AppStateManager : NSObject

@property (nonatomic, readonly) NSInteger startCount;

//initializer function to init with options, crash wrapper, file manager, current date provider, sysctl, dispatch queue wrapper, notification center wrapper
- (instancetype)initWithCurrentDateProvider:(id<S24CurrentDateProvider>)currentDateProvider
                         sysctl:(S24Sysctl *)sysctl
           dispatchQueueWrapper:(S24DispatchQueueWrapper *)dispatchQueueWrapper
                  notificationCenterWrapper:(S24NSNotificationCenterWrapper *)notificationCenterWrapper;

#if S24_CAN_USE_UIDEVICE

- (void)start;
- (void)stop;
- (void)stopWithForce:(BOOL)forceStop;

/**
 * Builds the current app state.
 *
 * @discussion The systemBootTimestamp is calculated by taking the current time and substracting
 * NSProcesInfo.systemUptime.  NSProcesInfo.systemUptime returns the amount of time the system has
 * been awake since the last time it was restarted. This means This is a good enough approximation
 * about the timestamp the system booted.
 */
- (S24AppState *)buildCurrentAppState;

- (S24AppState *)loadPreviousAppState;

- (void)storeCurrentAppState;

- (void)updateAppState:(void (^)(S24AppState *))block;

#endif


@end

NS_ASSUME_NONNULL_END
