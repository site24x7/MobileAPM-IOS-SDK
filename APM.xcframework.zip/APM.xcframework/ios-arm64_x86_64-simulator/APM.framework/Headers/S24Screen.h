//
//  S24Screen.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 02/03/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "S24ScreenFrames.h"

NS_ASSUME_NONNULL_BEGIN

@interface S24Screen : NSObject

@property (nonatomic, assign, readonly) NSUInteger initTotal;
@property (nonatomic, assign, readonly) NSUInteger initFrozen;
@property (nonatomic, assign, readonly) NSUInteger initSlow;

@property (nonatomic, assign) NSUInteger finalTotal;
@property (nonatomic, assign) NSUInteger finalFrozen;
@property (nonatomic, assign) NSUInteger finalSlow;

@property (nonatomic, readonly) NSString *name;
//below timestarted for calculating duration and recorded using CACurrentMediaTime() in UIViewController
@property (nonatomic) NSNumber *timestarted;
//below start time will be in currentMillis
@property (nonatomic) NSString *startTime;
@property (nonatomic) NSUInteger duration;

- (instancetype) initWithName:(NSString *)screenName initTotal:(NSUInteger)initTotal initFrozen:(NSUInteger)initFrozen initSlow:(NSUInteger)initSlow;

- (instancetype) initWithName:(NSString *)screenName initialFrameValues:(S24ScreenFrames *)screenFrames;

- (instancetype) initWithName:(NSString *)screenName startTime:(NSNumber *)timeStarted initialFrameValues:(S24ScreenFrames *)screenFrames;

- (instancetype) initWithName:(NSString *)screenName;

- (NSDictionary*) getFinalFrames;

- (void) setFinalFrames;

@end

NS_ASSUME_NONNULL_END
