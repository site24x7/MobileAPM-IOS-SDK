//
//  S24CurrentDateProvider.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 14/02/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol S24CurrentDateProvider <NSObject>

- (NSDate *)date;

- (dispatch_time_t)dispatchTimeNow;

- (NSInteger)timezoneOffset;

@end

NS_ASSUME_NONNULL_END
