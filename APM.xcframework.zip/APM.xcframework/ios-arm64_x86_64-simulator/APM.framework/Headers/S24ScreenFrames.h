//
//  S24ScreenFrames.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 17/01/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "S24Constants.h"

#if S24_CAN_USE_UIDEVICE
#  import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface S24ScreenFrames : NSObject

- (instancetype)initWithTotal:(NSUInteger)total frozen:(NSUInteger)frozen slow:(NSUInteger)slow;

@property (nonatomic, assign, readonly) NSUInteger total;
@property (nonatomic, assign, readonly) NSUInteger frozen;
@property (nonatomic, assign, readonly) NSUInteger slow;

@end

#endif

NS_ASSUME_NONNULL_END
