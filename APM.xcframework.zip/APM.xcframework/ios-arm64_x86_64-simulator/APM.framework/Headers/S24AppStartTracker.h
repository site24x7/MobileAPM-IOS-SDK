//
//  S24AppStartTracker.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 01/02/23.
//  Copyright © 2023 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "S24AppStateManager.h"
#import "S24CurrentDateProvider.h"
#import "S24Sysctl.h"
#import "S24DispatchQueueWrapper.h"
#import "S24AppStartMeasurement.h"

NS_ASSUME_NONNULL_BEGIN

#if S24_CAN_USE_UIDEVICE

@interface S24AppStartTracker : NSObject

@property (nonatomic) BOOL isAppStartTimeSent;
@property (nonatomic) int64_t appStartDuration;
@property (nonatomic) S24AppStartType *appStartType;

- (instancetype)initWithCurrentDateProvider:(id<S24CurrentDateProvider>)currentDateProvider
                       dispatchQueueWrapper:(S24DispatchQueueWrapper *)dispatchQueueWrapper
                            appStateManager:(S24AppStateManager *)appStateManager
                                     systemctl:(S24Sysctl *)systemctl
             enablePreWarmedAppStartTracing:(BOOL)enablePreWarmedAppStartTracing;

- (instancetype)initWithCurrentDateProvider:(id<S24CurrentDateProvider>)currentDateProvider
                       dispatchQueueWrapper:(S24DispatchQueueWrapper *)dispatchQueueWrapper
                                     systemctl:(S24Sysctl *)systemctl
             enablePreWarmedAppStartTracing:(BOOL)enablePreWarmedAppStartTracing;

- (void)start;

- (void)stop;

-(S24AppStartMeasurement*) getFinalAppStartMeasurement;

@end

#endif

NS_ASSUME_NONNULL_END
