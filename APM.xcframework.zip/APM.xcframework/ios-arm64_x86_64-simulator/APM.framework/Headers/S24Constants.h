//
//  S24Constants.h
//  APM
//
//  Created by Murugappan V R on 21/01/21.
//  Copyright © 2021 Zoho Corporation. All rights reserved.
//

#ifndef S24Constants_h
#define S24Constants_h

#import <Foundation/Foundation.h>
#if TARGET_OS_IOS || TARGET_OS_TV
#   define S24_CAN_USE_UIDEVICE 1
#else
#   define S24_CAN_USE_UIDEVICE 0
#endif

#if defined(__GNUC__)
#   define S24_COMPILER_GCC_COMPATIBLE 1
#endif

#if !defined(UNLIKELY) && (defined(S24_COMPILER_GCC_COMPATIBLE) && S24_COMPILER_GCC_COMPATIBLE)
#   define UNLIKELY(x) __builtin_expect(!!(x), 0)
#endif

#if !defined(UNLIKELY)
#define UNLIKELY(x) (x)
#endif

// Time Constants
static int const SessionExpiryPeriodInMillis = 15 * 60 * 1000; // 15 minutes

//Uploader Constants
static NSString *_Nonnull const statusCodeDescriptionAccepted = @"Request succeeded";
static NSString *_Nonnull const deviceInfo = @"deviceInfo";
static NSString *_Nonnull const sessionInfo = @"sessionInfo";
static NSString *_Nonnull const httpCalls = @"httpCalls";
static NSString *_Nonnull const screens = @"screens";
static NSString *_Nonnull const config = @"config";
static NSString *_Nonnull const protocolVersion= @"protocolVersion";

// Device Info Constants
static NSString *_Nonnull const osVersion = @"osversion";
static NSString *_Nonnull const appRelease = @"apprelease";
static NSString *_Nonnull const appVersion = @"appversion";
static NSString *_Nonnull const platform = @"platform";
static NSString *_Nonnull const deviceModel = @"deviceModel";
static NSString *_Nonnull const orientation = @"orientation";
static NSString *_Nonnull const environment= @"environment";

// Session Info Constants
static NSString *_Nonnull const connectionType = @"connection_type";
static NSString *_Nonnull const uid = @"uid";
static NSString *_Nonnull const guid = @"guid";
static NSString *_Nonnull const sstime = @"sstime";
static NSString *_Nonnull const sessionId = @"session_id";

//screen orientation constants
static NSString *_Nonnull const portrait = @"portrait";
static NSString *_Nonnull const landscape = @"landscape";

//preference ids
static NSString *_Nonnull const s24IdentifierUserDefaultsKey = @"com.s24.user.identifier";
static NSString *_Nonnull const s24IdentifierSessionDefaultsKey = @"com.s24.session.identifier";
#endif /* S24Constants_h */
