//
//  S24CrashReporterSink.h
//  APM
//
//  Created by Veera Brahmam Pydimarri on 25/04/22.
//  Copyright © 2022 Zoho Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSCrashReportFilter.h"

NS_ASSUME_NONNULL_BEGIN

@interface S24CrashReporterSink : NSObject<KSCrashReportFilter>

@property (nonatomic, strong) NSOperationQueue *operationQueue;


- (id <KSCrashReportFilter>) defaultCrashReportFilterSetAppleFmt;
- (id) initWithURL:(NSURL*)url;

@end

NS_ASSUME_NONNULL_END

