//
//  S24APM.h
//  APM
//
//  Created by Kurian Abraham on 12/03/15.
//  Copyright (c) 2015 Zoho Corporation. All rights reserved.
//

@import Foundation;

#import "S24Transaction.h"

/*!
 The S24APM class provides class methods to initialize and use the APM agent. You must obtain an application key from Site24x7 to use the agent.
 */
@interface S24APM : NSObject

/*!
 Initializes the APM agent. This should be called in main.m when your application launches.
 @param appKey The application key.
 */
+ (void)startWithAppKey:(NSString *)appKey;

/*!
 Initializes the APM agent. This should be called in main.m when your application launches.
 @param appKey The application key.
 @param interval The upload interval in seconds. The default value is 60 seconds.
 */
+ (void)startWithAppKey:(NSString *)appKey interval:(NSUInteger)interval;

/*!
 Initializes the APM agent. This should be called in main.m when your application launches.
 @param appKey The application key.
 @param interval The upload interval in seconds. The default value is 60 seconds.
 @param server The data collection server.
 */
+ (void)startWithAppKey:(NSString *)appKey interval:(NSUInteger)interval server:(NSURL *)server;

/*!
 Start a transaction. This method is thread-safe.
 @param name The transaction name.
 @return A transaction object.
 */
+ (S24Transaction *)startTransactionWithName:(NSString *)name;

/*!
 Stop a transaction. This method is thread-safe.
 @param transaction A transaction object.
 */
+ (void)stopTransaction:(S24Transaction *)transaction;

/*!
 Uploads recorded data to the server immediately instead of waiting for the next upload interval. If you've configured a large upload interval, you may want to manually flush data. This method is thread-safe.
 */
+ (void)flush;

- (instancetype)init NS_UNAVAILABLE;

@end
