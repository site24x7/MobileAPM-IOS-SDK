//
//  ZASettings.h
//  JAnalytics
//
//  Created by Saravanan S on 29/07/19.
//  Copyright © 2019 zoho. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZASettings : NSObject

@property BOOL enableScreenTracking;

+(ZASettings * _Nonnull) getInstance;
@end

NS_ASSUME_NONNULL_END
