#import <Foundation/Foundation.h>
@class ZAPrivateObject;

typedef enum {
	
	ZAEventTypeNone

}ZAEventType;

@interface ZAEventsEnum : NSObject

+ (ZAPrivateObject *)formatTypeToPrivateObject:(ZAEventType)formatType;

@end
