//
//  ZABundle.h
//  Pods
//
//  Created by Saravanan S on 17/07/18.
//

#import <Foundation/Foundation.h>

@interface ZABundle : NSBundle

@property (nonatomic, retain) NSString * _Nullable lang;
@property (nonatomic, retain) NSString * _Nullable location;
+(NSBundle*) getMainBundle;

+(ZABundle * _Nonnull) getInstance;

-(NSBundle * _Nonnull) getAnalyticLanguageBundle;

-(NSBundle * _Nonnull) getBugSquashLanguageBundle;

-(NSBundle * _Nonnull) getAnalyticBundle;

-(NSBundle * _Nonnull) getBugSquashBundle;

@end
