//
//  ZATheme.h
//  JAnalytics
//
//  Created by Saravanan S on 19/07/18.
//

#import <Foundation/Foundation.h>
#if !TARGET_OS_OSX
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@protocol ZATheme <NSObject>
#if !TARGET_OS_OSX
@optional
-(UIColor *)tintColor;
-(UIColor *)barTintColor;
-(BOOL) translucent;
-(NSDictionary *)titleTextAttributes;
-(NSDictionary *)barButtontitleTextAttributes;
#endif
@end

@protocol ZASettingsTheme <NSObject>
#if !TARGET_OS_OSX
@optional
-(UIColor *)viewBGColor;
-(UIColor *)cellBGColor;
-(UIColor *)cellTextColor;
-(UIColor *)footerTextColor;
-(UIColor *)switchOnTintColor;
-(UIColor *)switchOffTintColor;
-(UIColor *)switchThumbTintColor;
-(UIColor *)switchTintColor;
-(CGFloat) switchScale;
-(UIColor *)tableViewSeparatorColor;

-(UIFont *)cellTextFont;
-(UIFont *)footerTextFont;
#if !TARGET_OS_WATCH
-(UIButton *)backButton;
#endif
-(CGFloat) lineSpacing;
-(CGSize) preferredContentSize;
#endif
-(NSString *)fontName;
@end

@protocol ZAFeedbackTheme <NSObject>
#if !TARGET_OS_OSX && !TARGET_OS_WATCH
@optional

-(UIColor *)viewBGColor;
-(UIColor *)contentBGColor;
-(UIColor *)switchOnTintColor;
-(UIColor *)switchOffTintColor;
-(UIColor *)switchThumbTintColor;
-(UIColor *)switchTintColor;
-(CGFloat) switchScale;

-(UIColor *)textFieldTextColor;
-(UIColor *)textFieldPlaceholderColor;
-(UIColor *)textViewTextColor;
-(UIColor *)textViewPlaceholderColor;

-(UIColor *)accessoryViewBGColor;
-(UIColor *)accessoryHeaderTextColor;
-(UIColor *)accessorySubHeaderTextColor;

-(UIColor *)collectionViewCellBorderColor;

-(UIColor *)separatorColor;

-(UIFont *)textFieldFont;
-(UIFont *)textViewFont;
-(UIFont *)keyboardAccessoryHeaderFont;
-(UIFont *)keyboardAccessorySubHeaderFont;

-(UIFont *)noImagePlaceholderFont;
-(CGSize)preferredContentSize;

-(UIColor *)attachmentTableHeaderTextColor;
-(UIColor *)attachmentTableCellFileNameTextColor;
-(UIColor *)attachmentTableCellSizeLabelTextColor;
-(UIColor *)attachmentTableCellXButtonColor;

-(UIFont *)attachmentTableHeaderTextFont;
-(UIFont *)attachmentTableCellFileNameTextFont;
-(UIFont *)attachmentTableCellSizeLabelTextFont;

-(UIKeyboardAppearance) keyboardAppearance;

-(UIColor *)pickerViewBGColor;
-(UIColor *)systemLogViewBGColor;
-(UIColor *)systemLogTextColor;
-(UIColor *)diagnosticInfoBGColor;
-(UIColor *)diagnosticInfoTextColor;

#endif
-(NSString *)fontName;
@end

@protocol ZACustomAlertTheme <NSObject>
#if !TARGET_OS_OSX
@optional
-(UIColor *)primaryColor;
-(UIColor *)secondaryColor;

-(NSDictionary *)titleTextAttributes;
-(NSDictionary *)descriptionTextAttributes;

-(CGFloat) buttonCornerRadius;

#endif

@end

@protocol ZAUserConsentTheme <ZACustomAlertTheme>
#if !TARGET_OS_OSX
@optional
-(NSDictionary *)privacyTextAttributes;
-(UIImage *)logoImage;
#endif
@end

@protocol ZAAppUpdateConsentTheme <ZACustomAlertTheme>
@optional
//ZACustomAlertTheme's Primary color will be applied to 'Update now' button background and title text color of other two buttons
//ZACustomAlertTheme's Secondary color will be applied as title text color of 'Update now' button and background color of other two buttons
//ZACustomAlertTheme's titleTextAttributes will be used to customise the title font and color
//ZACustomAlertTheme's descriptionTextAttributes will be used to customise the description font and color
//ZACustomAlertTheme's buttonCornerRadius will be used to change the button radius using this method

-(NSDictionary *)buttonTitleTextAttributes;
-(NSDictionary *)versionTextAttributes;
-(NSDictionary *)readMoreTextAttributes;

@end

@interface ZAThemeManager : NSObject
+(id <ZATheme>)sharedThemeManager;
+(id <ZASettingsTheme>)sharedSettingsThemeManager;
+(id <ZAFeedbackTheme>)sharedFeedbackThemeManager;
+(id <ZACustomAlertTheme>)sharedCustomAlertThemeManager;
+(id <ZAUserConsentTheme>)sharedUserConsentThemeManager;
+(id <ZAAppUpdateConsentTheme>)sharedAppUpdateConsentThemeManager;

+(void) setTheme:(id <ZATheme>) theme;
+(void) setSettingsTheme:(id <ZASettingsTheme>) settingsTheme;
+(void) setFeedbackTheme:(id <ZAFeedbackTheme>) feedbackTheme;
+(void) setCustomAlertTheme:(id <ZACustomAlertTheme>) customAlertTheme;
+(void) setUserConsentTheme:(id <ZAUserConsentTheme>) userConsentTheme;
+(void) setAppUpdateConsentTheme:(id <ZAAppUpdateConsentTheme>) appUpdateConsentTheme;
@end

@interface ZADefaultTheme : NSObject <ZATheme>
@end

@interface ZADefaultSettingsTheme : NSObject <ZASettingsTheme>
@end

@interface ZADefaultFeedbackTheme : NSObject <ZAFeedbackTheme>
@end

@interface ZADefaultCustomAlertTheme : NSObject <ZACustomAlertTheme>
@end

@interface ZADefaultUserConsentTheme : NSObject <ZAUserConsentTheme>
@end

@interface ZADefaultAppUpdateConsentTheme : NSObject <ZAAppUpdateConsentTheme>
@end
