//
//  ZAEnums.h
//  JAnalytics
//
//  Created by Giridhar on 27/02/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#ifndef ZAEnums_h
#define ZAEnums_h


/**
 Specifies the Build type. You usually need not set this. This is used for Building URL and sending it to Zoho, localzoho or pre servers.
*/
typedef NS_ENUM(NSInteger, JBuildType)
{
    /**
     *  Points to local server. jproxy.localzoho.com. You need to be connected to Zoho-Handhelds or ZohoCorp wifi to push data to this server
     */
    Local = 0,
    /**
     *  Points to live servers, use this mode when app goes live. Points to jproxy.zoho.com
     */
    Live,
    /**
     *  Points to pre server, prejproxy.zoho.com
     */
    Pre,
};


/**
 *  Specifices they type of mode JAnalytics should run on
 */


typedef NS_ENUM(NSInteger, JDebugMode)
{
    /**
     *  Development mode is when you are developing the app, use this mode so that the analytics data doesn't interfere with the real time user analytics data
     */
    Development = 0,
    /**
     *  Use this mode when app goes live, this is data is typically shown in the website
     */
    Production,
    /**
     *  Use this for testing JAnalytics services.
     */
    Testing
};

typedef NS_ENUM(NSInteger, JURLPath)
{
  JURLPathScreens = 1337,
  JURLPathEvents,
  JURLPathSession,
  JURLPathRequests,
  JURLPathRegisterUser,
  JURLPathCrash,
  JURLPathDeviceInfo,
  JURLPathEvents_Log,
  JURLPathSession_history,
  JURLPathCurrentSession_History,
  JURLPathNonFatalErrors,
  JURLPathUpdateInfo,
  JURLPathUpdateStats,
  JURLPathUnRegisterUser,
  JURLPathRegisterDevice,
  JURLPathUpdateDeviceInfo,
  JURLPathUpdateOptStatus,
  JURLPathUpdateTrackingStatus,
  JURLPathRateUs,
  JURLPathMapdcdeviceid,
  JURLPathSyncRateUsInfo,
  JURLPathSyncApiCriteriaInfo,
  JURLPathSyncRemoteConfigInfo
};

typedef NS_ENUM(NSInteger, JAStatus)
{
  JAStatusSuccess = 2000,
  JAStatusInvalidApiToken = 3000,
  JAStatusInvalidApp = 3001,
  JAStatusJsonNull = 3002,
  JAStatusOtherExcep = 3003,
  JAStatusInvalidDeviceId = 3004,
  JAStatusJsonExcep = 3005,
  JAStatusInvalidUser = 3006,
};

typedef NS_ENUM(NSInteger, JATrackingStatus)
{
  JATrackingStatusOff = 0,
  JATrackingStatusOn
};

typedef NS_ENUM(NSInteger, JACrashStatus)
{
  JACrashStatusOff = 0,
  JACrashStatusOn
};

typedef NS_ENUM(NSInteger, JAPIIStatus)
{
  JAPIIStatusTrackingAuthOff = -2,
  JAPIIStatusUnknown,//New user
  JAPIIStatusUnAuthorized,//User decided to opt-out
  JAPIIStatusAuthorized//User opted-in
};

typedef NS_ENUM(NSInteger, JRateUsAction)
{
  JRateUsActionCancel = -1,
  JRateUsActionSendFeedback,
  JRateUsActionRateOnStore
};

typedef NS_ENUM(NSInteger, JRateUsType)
{
  JRateUsTypePopup1 = 1,
  JRateUsTypePopup2
};

typedef NS_ENUM(NSInteger, JRateUsSource)
{
  JRateUsSourceAuto = 1,
  JRateUsSourceManual
};

typedef NS_ENUM(NSInteger, JAUserStatus)
{
  JAUserStatusAuthorized = 0,
  JAUserStatusUnAuthorized,
  JAUserStatusDontTrack
};

typedef NS_ENUM(NSInteger, CrashPreferenceType) // Crash Authorization Result Type
{
  CrashPreferenceTypeAlwaysSend = 0,
  CrashPreferenceTypeSendNow,
  CrashPreferenceTypeNotNow,
  CrashPreferenceTypeNeverAsk
};

typedef void (^UserConsentPresentCompletionBlock) (bool status, NSError* error);

typedef void (^UserConsentDismissCompletionBlock) (int status);

typedef void (^CrashConsentDismissCompletionBlock) (int status);

#pragma BugSquashKit

typedef NS_ENUM(NSInteger, ZBFeedbackType)
{
  ZBFeedbackTypeScreenshot = 0,
  ZBFeedbackTypeFeedbackOnly,
  ZBFeedbackTypeHelpMe,
  ZBFeedbackTypeReport
};

typedef NS_ENUM(NSInteger, ZBActionType)
{
  ZBActionTypeShake = 0,
  ZBActionTypeSettings
};

#endif /* ZAEnums_h */

typedef NS_ENUM(NSInteger, ZAAlertType)
{
  ZAAlertTypeUserConsent1 = 0,
  ZAAlertTypeUserConsent2,
  ZAAlertTypeAppUpdate,
  ZAAlertTypeWhatsNew
};

typedef NS_ENUM(NSInteger, ZAPrivacyConsentType)
{
  ZAPrivacyConsentType1 = 0,
  ZAPrivacyConsentType2
};


typedef NS_ENUM(NSUInteger, ZUAlertType)
{
  ZUAlertTypeIgnore = 1,   // Presents User with option to download the app now, remind him/her later, or to skip/ignore this version all together
  ZUAlertTypeRemind,       // Presents user with option to update app now or at next launch
  ZUAlertTypeCustom,        // Customize the app update to your app
  ZUAlertTypeNone          // Don't show the alert type , useful for skipping Patch, Minor, Major updates
};

typedef NS_ENUM(NSUInteger, ZAUpdateAction)
{
  ZAUpdateActionImpression = 1,
  ZAUpdateActionDownload,
  ZAUpdateActionLater,
  ZAUpdateActionIgnore
};

typedef NS_ENUM(NSUInteger, ZUButtonType)
{
  ZUButtonTypeDownload = 1,   // Download now
  ZUButtonTypeRemind,       // Remind me later
  ZUTapTypeIgnore,        // Ignore this version
  
};

/**
 *  Log levels are used to print and push the levels of logs to the server.
 */

typedef NS_ENUM(NSUInteger, ZALogLevel){
  ZALogLevelOff       = 0,
  ZALogLevelVerbose,
  ZALogLevelDebug,
  ZALogLevelInfo,
  ZALogLevelWarning,
  ZALogLevelError,
  ZALogLevelAll
};

typedef NS_ENUM(NSInteger, ZPIIType)
{
  emailID = 0,
  customerID
};


