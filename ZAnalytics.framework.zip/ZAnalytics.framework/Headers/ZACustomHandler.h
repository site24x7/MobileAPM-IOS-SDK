//
//  ZACustomHandler.h
//  JAnalytics
//
//  Created by Saravanan S on 26/07/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZAEnums.h"

#if !TARGET_OS_OSX
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@protocol ZACustomHandler <NSObject>

@optional
-(void) openURL: (NSURL*) url;
-(void) userConsentPresent : (bool) status withError: (NSError*) error;
-(void) userConsentDismiss : (int) status;

-(void) willSendCrashReport : (bool) status;
-(void) crashConsentPresent : (bool) status withError: (NSError*) error;
-(void) crashConsentDismiss : (int) status;

-(void) feedbackScreenWillOpen: (id) viewController;
-(void) feedbackScreenWillClose;

-(void) sendFeedbackBegan;
-(void) sendFeedbackEndWithSuccess;
-(void) sendFeedbackEndWithFailure;
-(NSString*) setFeedbackTag;

-(void) sendReportBegan;
-(void) sendReportEndWithSuccess;
-(void) sendReportEndWithFailure;

-(void) rateUsActionCompletionHandler:(JRateUsAction) action;
@end

@interface ZACustomHandlerManager : NSObject
@property (nonatomic) id <ZACustomHandler> sharedCustomHandler;
+(ZACustomHandlerManager*) sharedHandlerManager;
+(void) setCustomHandler:(id <ZACustomHandler>) handler;

+(void) userConsentPresent : (bool) status withError: (NSError*) error;
+(void) userConsentDismiss : (int) status;

+(void) willSendCrashReport : (bool) status;
+(void) crashConsentPresent : (bool) status withError: (NSError*) error;
+(void) crashConsentDismiss : (int) status;

+(void) feedbackScreenWillOpen: (id) viewController;
+(void) feedbackScreenWillClose;

+(void) sendFeedbackBegan;
+(void) sendFeedbackEndWithSuccess;
+(void) sendFeedbackEndWithFailure;
+(NSString*) setFeedbackTag;

+(void) sendReportBegan;
+(void) sendReportEndWithSuccess;
+(void) sendReportEndWithFailure;

+(void) openURL: (NSURL*) url;

+(void) rateUsActionCompletionHandler:(JRateUsAction) action;
@end

