
require 'xcodeproj'

# has to copy/move a plist add it to the main target


class PrebuildConfig

	$projectName; # main target
	$targetName; # the pod name probably it should be JAnalytics
	$podTargetName = "ZAnalytics" # the pod name probably it should be JAnalytics
	$fileName = "ZAnalytics-Config.plist" # name of the file -> info.plist
	$file_ref = nil

	def self.copyFileIfNotExists(target_group_name)
  
	  project_path = Dir.pwd+"/"+target_group_name
	  pods_path = File.expand_path("Pods/Pods.xcodeproj")
	  pod_project = Xcodeproj::Project.open(pods_path)
  
  
	  pod_project.targets.each do |target|
	
		if target.name.start_with?($podTargetName)
		  target.source_build_phase.files.each do |pbx_build_file|
			if pbx_build_file.file_ref.real_path.to_s.end_with?($fileName)			  
			  FileUtils.cp(pbx_build_file.file_ref.real_path.to_s, project_path,:verbose => false) unless File.exist?(project_path+"/"+$fileName)
			  $file_ref = project_path + "/" + $fileName
			  File.chmod(0777,$file_ref)
			  return $file_ref
			end
		  end
		end
	  end
	  return $file_ref
	end

	# custom main function
	  def self.main(projectName, selectedTargetName)
  
	  $projectName=projectName
	  $targetName=selectedTargetName
  
	  main_project_path = File.expand_path($projectName)
	  project = Xcodeproj::Project.open(main_project_path)
  
	  project.targets.each do |target|
	
		if target.name == $targetName
		target_group_name = nil
		target.build_configurations.each do |config|
		  info_path = config.build_settings["INFOPLIST_FILE"]
		  target_group_name = File.dirname(info_path)
		  break
		end
	
		if target_group_name != nil
	  
		  target_group = project.main_group.find_subpath(target_group_name)
		  if target_group != nil
			if target_group.find_subpath($fileName).nil?
			  file_ref = copyFileIfNotExists(target_group_name)
			  if !file_ref.nil?
				files = target_group.new_file(file_ref)
				target.add_file_references([files])
				puts '\nAdded "'+$fileName+'" to "'+target_group_name+'"\n'
			  end
			  else
				puts '\nFile "'+$fileName+'" already exists in "'+target_group_name+'"\n'
			end
		  end
		end   
		end
	  end
  
	  project_file_name_proj = $projectName
	  project.save(project_file_name_proj)
  
	end

	# function that returns list of targets for the given project 
	def self.getTargetLists(projectName)
		list=""
		main_project_path = File.expand_path(projectName)
			project = Xcodeproj::Project.open(main_project_path)
			project.targets.each do |target|
			list.concat("#{target.name},")
		end
		puts list
	end

end
