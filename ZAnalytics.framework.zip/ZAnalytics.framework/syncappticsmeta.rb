
require 'xcodeproj'
require 'fileutils'
require "net/http"
require "uri"
require "json"

class AppInfo
  
  $projectName # project name
  $targetName # target name
  $fileName = "ZAEventsEnum" #
  
  def self.parseAppticsMetaJson()
  
  data_hash = JSON.parse(File.read('/tmp/AppticsMeta.json'))
  objch_fc = "#import <Foundation/Foundation.h>\n@class ZAPrivateObject;\n\ntypedef enum {\n"
  objcm_fc = "#import \"#{$fileName}.h\"\n#import \"ZAPrivate.h\"\n\n"
  objcm_fc.concat("@implementation ZAEventsEnum : NSObject\n\n")
  objcm_fc.concat("+ (ZAPrivateObject *)formatTypeToPrivateObject:(ZAEventType)formatType {\n\n")
  objcm_fc.concat("\tZAPrivateObject *result = nil;\n\n")
  objcm_fc.concat("\tswitch(formatType) {\n")
  
  jsondata_fc = "{\n  \"apptics\":\n  {\n"
  
  data_hash = data_hash["data"]
  data_hash.map do | group, events|
  group = group.strip.gsub(/[^0-9A-Za-z]/, '_')
  
  
  
  events.map do | event |
  event.map do | name, id|
  name = name.strip.gsub(/[^0-9A-Za-z]/, '_')
  objch_fc.concat("\tZAEventType_#{group}_#{name},\n\n")
  objcm_fc.concat("\t\tcase ZAEventType_#{group}_#{name}:\n")
  objcm_fc.concat("\t\t\tresult = [[ZAPrivateObject alloc] initWith:@\"#{id}\"];\n")
  objcm_fc.concat("\t\t\tbreak;\n")
  
  jsondata_fc.concat("    \"#{id}\":{\"group\":\"#{group}\", \"event\":\"#{name}\"},\n")
end
end

end

objch_fc.concat("\tZAEventTypeNone\n\n")
objch_fc.concat("}ZAEventType;\n\n")
objch_fc.concat("@interface ZAEventsEnum : NSObject\n\n")
objch_fc.concat("+ (ZAPrivateObject *)formatTypeToPrivateObject:(ZAEventType)formatType;\n\n")
objch_fc.concat("@end")

objcm_fc.concat("\t\tdefault:\n")
objcm_fc.concat("\t\t\tresult = [[ZAPrivateObject alloc] initWith:nil];\n")
objcm_fc.concat("\t}\n")
objcm_fc.concat("\treturn result;\n\n")
objcm_fc.concat("}\n")
objcm_fc.concat("@end")

jsondata_fc.concat("    \"\":{\"group\":\"\",\"event\":\"\"}")
jsondata_fc.concat("\n  }\n}")

out_file = File.new("/tmp/#{$fileName}.json", "w")
out_file.puts(jsondata_fc)
out_file.close

out_file = File.new("/tmp/#{$fileName}.h", "w")
out_file.puts(objch_fc)
out_file.close

out_file = File.new("/tmp/#{$fileName}.m", "w")
out_file.puts(objcm_fc)
out_file.close

end

def self.copyItemToTheProject(path)

project_path = path+"/ZAnalytics/native/JAnalytics/common/Modal"

tmpDir = Dir["/tmp/#{$fileName}.*"]
tmpDir.each do | filename|
  basename = File.basename(filename)
  file_ref = project_path + "/" + basename
  File.chmod(0777,file_ref)
  FileUtils.cp(filename, project_path, :verbose => false)
  File.chmod(0555,file_ref)
  puts 'Copied '+basename+' to '+project_path+'\n'
end

end

# custom main function
def self.main(path)
parseAppticsMetaJson
copyItemToTheProject(path)
end

end
