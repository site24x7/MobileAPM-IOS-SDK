require 'xcodeproj'
require 'cgi'

project_path = ARGV[0]
pro_dir = Dir.pwd
project = Xcodeproj::Project.open(project_path)
def self.schemes(project_path)
schemes = Dir[File.join(project_path, 'xcshareddata', 'xcschemes', '*.xcscheme')].map do |scheme|
  File.basename(scheme, '.xcscheme')
end
schemes << File.basename(project_path, '.xcodeproj') if schemes.empty?
schemes
end

proj_schemes = schemes project_path
proj_schemes.each  do | _scheme |
  schemePath = Xcodeproj::XCScheme.shared_data_dir(project_path) + (_scheme + ".xcscheme")
  scheme = Xcodeproj::XCScheme.new(schemePath)
  
  # 4) Add a "Pre-Actions" script to the "BuildAction" of ZAnalytics.xcscheme.
  
  buildActions = scheme.build_action.xml_element
  
  preActions = buildActions.elements["PreActions"]
  
  if preActions == nil
    preActions = REXML::Element.new("PreActions")
    buildActions.unshift(preActions)
  end
  
  executionAction = preActions.elements["ExecutionAction"]
  
  scriptText=nil;
  if executionAction
    scriptText = executionAction.elements["ActionContent"].attributes.get_attribute("scriptText").to_s
  end
  
  if scriptText == nil or not scriptText.include? "./Pods/ZAnalytics/native/scripts/syncappticsmeta"
    executionAction = REXML::Element.new("ExecutionAction", preActions)
    executionAction.add_attribute("ActionType","Xcode.IDEStandardExecutionActionsCore.ExecutionActionType.ShellScriptAction")
    
    actionContent = REXML::Element.new("ActionContent", executionAction)
    actionContent.add_attribute("title", "Run Script")
    scriptText = "cd \""+pro_dir+"\";\nbash \"./Pods/ZAnalytics/native/scripts/syncappticsmeta\""
    actionContent.add_attribute("scriptText", scriptText)
  end
  
  scheme.save!
  puts 'Added run-script for scheme ' + _scheme + '\n'
end

